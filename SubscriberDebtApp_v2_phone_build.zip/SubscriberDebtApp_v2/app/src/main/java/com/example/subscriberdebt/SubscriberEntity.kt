package com.example.subscriberdebt

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subscribers")
data class SubscriberEntity(
    @PrimaryKey(autoGenerate = true) var id: Long = 0,
    var c01: String = "", var c02: String = "", var c03: String = "", var c04: String = "",
    var c05: String = "", var c06: String = "", var c07: String = "", var c08: String = "",
    var c09: String = "", var c10: String = "", var c11: String = "", var c12: String = "",
    var c13: String = "", var c14: String = "", var c15: String = "", var c16: String = "",
    var c17: String = "", var c18: String = "", var c19: String = "", var c20: String = "",
    var c21: String = "", var c22: String = "", var c23: String = "", var c24: String = "",
    var c25: String = "", var c26: String = "", var c27: String = "", var c28: String = "",
    var c29: String = "", var c30: String = "", var c31: String = "", var c32: String = "",
    var c33: String = "", var c34: String = "", var c35: String = "", var c36: String = "",
    var c37: String = "", var c38: String = "", var c39: String = "", var c40: String = "",
    var c41: String = "", var c42: String = "", var c43: String = "", var c44: String = ""
)
