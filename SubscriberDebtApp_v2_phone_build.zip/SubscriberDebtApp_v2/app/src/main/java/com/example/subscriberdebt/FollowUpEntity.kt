package com.example.subscriberdebt

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "followups")
data class FollowUpEntity(
    @PrimaryKey(autoGenerate = true) var id: Long = 0,
    var subscriberId: Long = 0,
    var route: String = "",
    var serial: String = "",
    var agreement: String = "",
    var name: String = "",
    var usageType: String = "",
    var debt: String = "",
    var unpaidMonths: String = "",
    var lastPaymentDate: String = "",
    var result: String = "",
    var amount: String = "",
    var commitmentDate: String = "",
    var leader: String = "",
    var worker: String = "",
    var followUpDate: String = ""
)
