package com.example.subscriberdebt

import android.app.AlertDialog
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var db: AppDatabase
    private lateinit var tvCount: TextView
    private lateinit var results: LinearLayout
    private lateinit var query: EditText
    private lateinit var method: Spinner
    private lateinit var route: Spinner
    private val methods = listOf("الاسم", "رقم الاتفاقية", "الرقم الحديدي", "رقم الهاتف", "الطريق / المسار")
    private val routes = listOf("اختر المسار") + (1..35).map { it.toString() }
    private val openExcel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) importExcel(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = AppDatabase.get(this)
        tvCount = findViewById(R.id.tvCount); results = findViewById(R.id.results)
        query = findViewById(R.id.etQuery); method = findViewById(R.id.spMethod); route = findViewById(R.id.spRoute)
        method.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, methods)
        route.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, routes)
        findViewById<Button>(R.id.btnImport).setOnClickListener { openExcel.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel")) }
        findViewById<Button>(R.id.btnDelete).setOnClickListener { confirmDelete() }
        findViewById<Button>(R.id.btnSearch).setOnClickListener { search() }
        findViewById<Button>(R.id.btnFollowups).setOnClickListener { showFollowups() }
        method.setOnItemSelectedListener(object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                route.visibility = if (position == 0) View.VISIBLE else View.GONE
            }
        })
        refreshCount()
    }

    private fun importExcel(uri: Uri) {
        lifecycleScope.launch {
            try {
                val list = withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { ExcelImporter.read(it) } ?: error("تعذر فتح الملف") }
                withContext(Dispatchers.IO) { db.subscriberDao().deleteAll(); db.subscriberDao().insertAll(list) }
                refreshCount(); results.removeAllViews()
                Toast.makeText(this@MainActivity, "تم استيراد ${list.size} مشترك بنجاح", Toast.LENGTH_LONG).show()
            } catch (e: Exception) { Toast.makeText(this@MainActivity, "فشل الاستيراد: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this).setTitle("تأكيد الحذف")
            .setMessage("سيتم حذف بيانات المشتركين فقط. ستبقى متابعة المديونية محفوظة.")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حذف") { _, _ -> lifecycleScope.launch(Dispatchers.IO) { db.subscriberDao().deleteAll(); withContext(Dispatchers.Main) { refreshCount(); results.removeAllViews(); Toast.makeText(this@MainActivity, "تم حذف بيانات المشتركين", Toast.LENGTH_SHORT).show() } } }.show()
    }

    private fun refreshCount() { lifecycleScope.launch { tvCount.text = "عدد المشتركين: ${withContext(Dispatchers.IO) { db.subscriberDao().count() }}" } }

    private fun search() {
        val q = query.text.toString().trim(); val p = method.selectedItemPosition
        if (p == 0 && route.selectedItemPosition == 0) { route.requestFocus(); Toast.makeText(this, "اختر المسار أولاً عند البحث بالاسم", Toast.LENGTH_SHORT).show(); return }
        if (q.isBlank() && p != 4) { query.error = "أدخل قيمة البحث"; return }
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { when(p) {
                0 -> db.subscriberDao().searchName(route.selectedItem.toString(), q)
                1 -> db.subscriberDao().searchAgreement(q)
                2 -> db.subscriberDao().searchIron(q)
                3 -> db.subscriberDao().searchPhone(q)
                else -> db.subscriberDao().searchRoute(q)
            } }
            results.removeAllViews()
            if (list.isEmpty()) { results.addView(TextView(this@MainActivity).apply { text = "لا توجد نتائج مطابقة"; textSize = 17f; setPadding(12,24,12,24) }) }
            list.forEach { addResult(it) }
        }
    }

    private fun addResult(s: SubscriberEntity) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14,14,14,14); setBackgroundResource(android.R.drawable.dialog_holo_light_frame) }
        box.addView(TextView(this).apply { text = "رقم الاتفاقية: ${s.c04}\nالاسم: ${s.c05}\nالمديونية: ${s.c07}\nرقم الهاتف: ${s.c21}"; textSize = 16f })
        box.addView(Button(this).apply { text = "إظهار جميع البيانات"; setOnClickListener { showDetails(s) } })
        box.addView(Button(this).apply { text = "نتيجة متابعة المديونية"; setOnClickListener { followUp(s) } })
        results.addView(box, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8, 0, 8) })
    }

    private fun showDetails(s: SubscriberEntity) {
        val sb = StringBuilder()
        ExcelImporter.headers.forEachIndexed { i, h -> sb.append(h).append(": ").append(value(s, i + 1)).append("\n\n") }
        val scroll = ScrollView(this); scroll.addView(TextView(this).apply { text = sb.toString(); textSize = 15f; setPadding(20, 10, 20, 10) })
        AlertDialog.Builder(this).setTitle("بيانات المشترك").setView(scroll).setPositiveButton("إغلاق", null).show()
    }

    private fun followUp(s: SubscriberEntity) {
        val options = arrayOf("تم تسديد مبلغ", "تم فصل المجاري", "تم فصل المياه بدون سحب العداد", "تم فصل المياه مع سحب العداد", "ملتزم بتسديد إلى")
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 8) }
        val result = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options) }
        val amount = EditText(this).apply { hint = "المبلغ"; inputType = 2 }
        val commitment = EditText(this).apply { hint = "تاريخ الالتزام (yyyy-MM-dd)" }
        val leader = EditText(this).apply { hint = "اسم رئيس الفرقة" }
        val worker = EditText(this).apply { hint = "العامل" }
        layout.addView(result); layout.addView(amount); layout.addView(commitment); layout.addView(leader); layout.addView(worker)
        fun updateFields() { amount.visibility = if (result.selectedItemPosition == 0) View.VISIBLE else View.GONE; commitment.visibility = if (result.selectedItemPosition == 4) View.VISIBLE else View.GONE }
        result.onItemSelectedListener = object: AdapterView.OnItemSelectedListener { override fun onNothingSelected(p: AdapterView<*>?) {} ; override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { updateFields() } }
        updateFields()
        AlertDialog.Builder(this).setTitle("نتيجة متابعة المديونية").setView(layout).setNegativeButton("إلغاء", null).setPositiveButton("حفظ البيانات") { _, _ ->
            val date = today(); val item = FollowUpEntity(subscriberId=s.id, route=s.c02, serial=s.c03, agreement=s.c04, name=s.c05, usageType=s.c06, debt=s.c07, unpaidMonths=s.c11, lastPaymentDate=s.c42, result=result.selectedItem.toString(), amount=amount.text.toString().trim(), commitmentDate=commitment.text.toString().trim(), leader=leader.text.toString().trim(), worker=worker.text.toString().trim(), followUpDate=date)
            lifecycleScope.launch(Dispatchers.IO) { db.followUpDao().insert(item) }
            Toast.makeText(this, "تم حفظ نتيجة المتابعة بتاريخ $date", Toast.LENGTH_SHORT).show()
        }.show()
    }

    private fun showFollowups() {
        lifecycleScope.launch {
            val all = withContext(Dispatchers.IO) { db.followUpDao().all() }
            val text = if (all.isEmpty()) "لا توجد نتائج متابعة محفوظة." else all.joinToString("\n\n") { "التاريخ: ${it.followUpDate}\nالمسار: ${it.route} | الاتفاقية: ${it.agreement}\nالاسم: ${it.name}\nنوع الاستخدام: ${it.usageType}\nالمديونية: ${it.debt}\nالأشهر غير المدفوعة: ${it.unpaidMonths}\nآخر دفع: ${it.lastPaymentDate}\nالنتيجة: ${it.result}${if(it.amount.isNotBlank()) "\nالمبلغ: ${it.amount}" else ""}${if(it.commitmentDate.isNotBlank()) "\nالالتزام حتى: ${it.commitmentDate}" else ""}\nرئيس الفرقة: ${it.leader} | العامل: ${it.worker}" }
            val scroll = ScrollView(this@MainActivity); scroll.addView(TextView(this@MainActivity).apply { this.text = text; textSize = 14f; setPadding(16,16,16,16) })
            AlertDialog.Builder(this@MainActivity).setTitle("متابعة المديونية").setView(scroll).setNegativeButton("إغلاق", null).setPositiveButton("إنشاء PDF") { _, _ -> createPdf(all) }.show()
        }
    }

    private fun createPdf(items: List<FollowUpEntity>) {
        if (items.isEmpty()) { Toast.makeText(this, "لا توجد بيانات لإنشاء التقرير", Toast.LENGTH_SHORT).show(); return }
        val doc = PdfDocument(); val pageInfo = PdfDocument.PageInfo.Builder(842, 595, 1).create(); val page = doc.startPage(pageInfo); val c = page.canvas; val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create("sans", Typeface.NORMAL); p.textSize = 13f; p.textAlign = Paint.Align.RIGHT
        c.drawText("نتيجة متابعة المديونية", 421f, 35f, p); p.textSize=10f; c.drawText("تاريخ التقرير: ${today()}", 800f, 55f, p)
        val headers = listOf("المسار","المسلسل","رقم الاتفاقية","الاسم","نوع الاستخدام","المديونية","الأشهر","آخر دفع","نتيجة المتابعة","المبلغ/التاريخ")
        val widths = floatArrayOf(45f,45f,65f,120f,75f,70f,50f,65f,100f,85f); var x=20f; val top=80f; val rowH=28f
        p.style=Paint.Style.STROKE; p.textSize=8f; for(w in widths){c.drawRect(x,top,x+w,top+rowH,p);x+=w}; x=20f; p.style=Paint.Style.FILL; p.textAlign=Paint.Align.CENTER
        headers.forEachIndexed { i,h -> c.drawText(h,x+widths[i]/2,top+18f,p);x+=widths[i] }
        items.take(15).forEachIndexed { r,it -> val y=top+rowH*(r+1); x=20f; val vals=listOf(it.route,it.serial,it.agreement,it.name,it.usageType,it.debt,it.unpaidMonths,it.lastPaymentDate,it.result, if(it.amount.isNotBlank()) it.amount else it.commitmentDate); vals.forEachIndexed { i,v -> p.style=Paint.Style.STROKE;c.drawRect(x,y,x+widths[i],y+rowH,p);p.style=Paint.Style.FILL;c.drawText(v.take(18),x+widths[i]/2,y+18f,p);x+=widths[i] } }
        p.textAlign=Paint.Align.CENTER;p.textSize=9f;c.drawText("الموزع", 80f, 555f,p);c.drawText("العامل", 220f,555f,p);c.drawText("رئيس الفرقة",360f,555f,p);c.drawText("قسم متابعة المديونية",520f,555f,p);c.drawText("المدير الفني",660f,555f,p);c.drawText("المدير التجاري",760f,555f,p)
        doc.finishPage(page)
        val file=File(getExternalFilesDir(null),"نتيجة_متابعة_المديونية_${today()}.pdf"); FileOutputStream(file).use{doc.writeTo(it)};doc.close()
        Toast.makeText(this,"تم إنشاء التقرير: ${file.name}\n${file.absolutePath}",Toast.LENGTH_LONG).show()
    }

    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun value(s: SubscriberEntity, i: Int): String = when(i){1->s.c01;2->s.c02;3->s.c03;4->s.c04;5->s.c05;6->s.c06;7->s.c07;8->s.c08;9->s.c09;10->s.c10;11->s.c11;12->s.c12;13->s.c13;14->s.c14;15->s.c15;16->s.c16;17->s.c17;18->s.c18;19->s.c19;20->s.c20;21->s.c21;22->s.c22;23->s.c23;24->s.c24;25->s.c25;26->s.c26;27->s.c27;28->s.c28;29->s.c29;30->s.c30;31->s.c31;32->s.c32;33->s.c33;34->s.c34;35->s.c35;36->s.c36;37->s.c37;38->s.c38;39->s.c39;40->s.c40;41->s.c41;42->s.c42;43->s.c43;44->s.c44;else->""}
}
