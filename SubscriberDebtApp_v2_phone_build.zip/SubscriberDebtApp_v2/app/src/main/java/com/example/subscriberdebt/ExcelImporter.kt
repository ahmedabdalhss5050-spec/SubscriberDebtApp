package com.example.subscriberdebt

import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.ss.usermodel.DateUtil
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*

object ExcelImporter {
    val headers = listOf(
        "اسم القارئ","الطريق","المسلسل","رقم الاتفاقيه","الاسم","نوع الاتفاقيه","المديونيه","المبيع","نظام الشقق","الاعباء",
        "عدد اشهر غير المدفوع","المبلغ المدفوع للدورة السابقه","تاريخ التحصيل للدورة السابقه","اسم الصندوق للدورة السابقه","عدد ايام التاخير",
        "تاريخ التحصيل للدورة الحالية","مبلغ التحصيل للدورة الحاليه","اسم الصندوق للدوره الحالية","نسبه التحصيل من المبيع","نسبة التحصيل من الرصيد",
        "رقم الهاتف","الرقم الحديدي","القراءه الحاليه","الوحدات المستهلكة","متوسط الاستهلاك","عدد اشهر الصفري","الترميز","الملتزمين",
        "المساعدات","عدد الادوار","عدد الشقق","عدد الفتحات","تاريخ اشتراك المياه","تاريخ اشتراك الصرف","حاله الاتفاقيه","العنوان",
        "عدد المساعدات","اجمالي مبلغ المساعدات","تاريخ اخر مساعده","العام","مبلغ اخر دفع","تاريخ اخر دفع","عدد مدفوعات خ/12 شهر","اجمالي مدفوعات12 شهر"
    )

    fun read(input: InputStream): List<SubscriberEntity> {
        XSSFWorkbook(input).use { wb ->
            val sheet = wb.getSheetAt(0)
            val header = sheet.getRow(0) ?: throw IllegalArgumentException("صف العناوين غير موجود")
            val map = mutableMapOf<String, Int>()
            for (c in 0 until header.lastCellNum) {
                val name = header.getCell(c)?.toString()?.trim().orEmpty()
                if (name.isNotEmpty()) map[name] = c
            }
            val missing = headers.filter { !map.containsKey(it) }
            if (missing.isNotEmpty()) throw IllegalArgumentException("أعمدة ناقصة: ${missing.joinToString("، ")}")

            val out = ArrayList<SubscriberEntity>()
            for (r in 1..sheet.lastRowNum) {
                val row = sheet.getRow(r) ?: continue
                if (headers.all { row.getCell(map[it]!!) == null || cell(row.getCell(map[it]!!)).isBlank() }) continue
                val e = SubscriberEntity()
                headers.forEachIndexed { i, h -> set(e, i + 1, cell(row.getCell(map[h]!!))) }
                out.add(e)
            }
            return out
        }
    }

    private fun cell(c: Cell?): String {
        if (c == null) return ""
        if (c.cellType == CellType.NUMERIC && DateUtil.isCellDateFormatted(c)) return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.dateCellValue)
        return DataFormatter().formatCellValue(c).trim()
    }

    private fun set(e: SubscriberEntity, i: Int, v: String) {
        when (i) {
            1->e.c01=v;2->e.c02=v;3->e.c03=v;4->e.c04=v;5->e.c05=v;6->e.c06=v;7->e.c07=v;8->e.c08=v;9->e.c09=v;10->e.c10=v;
            11->e.c11=v;12->e.c12=v;13->e.c13=v;14->e.c14=v;15->e.c15=v;16->e.c16=v;17->e.c17=v;18->e.c18=v;19->e.c19=v;20->e.c20=v;
            21->e.c21=v;22->e.c22=v;23->e.c23=v;24->e.c24=v;25->e.c25=v;26->e.c26=v;27->e.c27=v;28->e.c28=v;29->e.c29=v;30->e.c30=v;
            31->e.c31=v;32->e.c32=v;33->e.c33=v;34->e.c34=v;35->e.c35=v;36->e.c36=v;37->e.c37=v;38->e.c38=v;39->e.c39=v;40->e.c40=v;
            41->e.c41=v;42->e.c42=v;43->e.c43=v;44->e.c44=v
        }
    }
}
