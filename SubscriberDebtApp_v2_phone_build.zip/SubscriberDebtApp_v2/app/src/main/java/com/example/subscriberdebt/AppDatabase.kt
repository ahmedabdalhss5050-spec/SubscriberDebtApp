package com.example.subscriberdebt

import android.content.Context
import androidx.room.*

@Dao
interface SubscriberDao {
    @Query("SELECT COUNT(*) FROM subscribers") suspend fun count(): Int
    @Query("SELECT * FROM subscribers ORDER BY id") suspend fun all(): List<SubscriberEntity>
    @Insert suspend fun insertAll(items: List<SubscriberEntity>)
    @Query("DELETE FROM subscribers") suspend fun deleteAll()
    @Query("SELECT * FROM subscribers WHERE c02 = :route AND c05 LIKE '%' || :q || '%' LIMIT 200") suspend fun searchName(route: String, q: String): List<SubscriberEntity>
    @Query("SELECT * FROM subscribers WHERE c04 LIKE '%' || :q || '%' LIMIT 200") suspend fun searchAgreement(q: String): List<SubscriberEntity>
    @Query("SELECT * FROM subscribers WHERE c22 LIKE '%' || :q || '%' LIMIT 200") suspend fun searchIron(q: String): List<SubscriberEntity>
    @Query("SELECT * FROM subscribers WHERE c21 LIKE '%' || :q || '%' LIMIT 200") suspend fun searchPhone(q: String): List<SubscriberEntity>
    @Query("SELECT * FROM subscribers WHERE c02 = :q LIMIT 200") suspend fun searchRoute(q: String): List<SubscriberEntity>
}

@Dao
interface FollowUpDao {
    @Insert suspend fun insert(item: FollowUpEntity)
    @Query("SELECT * FROM followups ORDER BY id DESC") suspend fun all(): List<FollowUpEntity>
    @Query("SELECT * FROM followups WHERE followUpDate = :date ORDER BY id DESC") suspend fun byDate(date: String): List<FollowUpEntity>
    @Query("SELECT COUNT(*) FROM followups") suspend fun count(): Int
}

@Database(entities = [SubscriberEntity::class, FollowUpEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun subscriberDao(): SubscriberDao
    abstract fun followUpDao(): FollowUpDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "subscribers.db").build().also { INSTANCE = it }
        }
    }
}
